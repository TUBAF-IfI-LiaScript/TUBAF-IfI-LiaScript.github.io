ace.require(["ace/snippets/lucene"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
