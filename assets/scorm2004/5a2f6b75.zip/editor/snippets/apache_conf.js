ace.require(["ace/snippets/apache_conf"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
