ace.require(["ace/snippets/scala"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
