ace.require(["ace/snippets/kotlin"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
