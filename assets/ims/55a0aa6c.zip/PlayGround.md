# First check for Git methods

Here you can test the github mechanisms ...

