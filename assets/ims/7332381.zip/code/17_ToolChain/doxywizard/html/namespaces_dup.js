var namespaces_dup =
[
    [ "doxyexample", "namespacedoxyexample.html", null ]
];