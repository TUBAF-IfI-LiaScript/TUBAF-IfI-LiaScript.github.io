<!--

author:   Andre Dietrich
email:    andre.dietrich@ovgu.de
version:  1.0.0
language: en_US
narrator: Deutsch Female

comment:  French dummy version.

translation: Deutsch   German.md
translation: English   ../README.md
translation: Français  French.md
translation: Русский   Russian.md

-->

# Lia-Script **Français**


Not yet translated French docs.

See the English version at:

https://liascript.github.io/?https://raw.githubusercontent.com/liaScript/docs/master/README.md
