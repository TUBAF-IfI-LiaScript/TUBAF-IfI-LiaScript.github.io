<!--

author:   Andre Dietrich
email:    andre.dietrich@ovgu.de
version:  1.0.0
language: en_US
narrator: Deutsch Female

comment:  German dummy version.

translation: Deutsch   German.md
translation: English   ../README.md
translation: Français  French.md
translation: Русский   Russian.md

-->

# Lia-Script **Deutsch**


                               --{{0}}--
Dies ist ein noch nicht übersetzter Dummy für die deutsche
LiaScript-Dokumentation.


Not yet translated German docs.

See the English version at:

https://liascript.github.io/?https://raw.githubusercontent.com/liaScript/docs/master/README.md
