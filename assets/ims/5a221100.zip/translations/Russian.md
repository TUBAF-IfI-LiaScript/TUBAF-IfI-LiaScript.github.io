<!--

author:   Andre Dietrich
email:    andre.dietrich@ovgu.de
version:  1.0.0
language: en_US
narrator: Deutsch Female

comment:  Russian dummy version.

translation: Deutsch   German.md
translation: English   ../README.md
translation: Français  French.md
translation: Русский   Russian.md

-->

# Lia-Script **Русский**


Not yet translated Russian docs.

See the English version at:

https://liascript.github.io/?https://raw.githubusercontent.com/liaScript/docs/master/README.md
