ace.require(["ace/snippets/fortran"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
