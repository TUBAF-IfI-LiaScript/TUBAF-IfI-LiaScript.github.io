ace.require(["ace/snippets/html_elixir"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
