using System;

namespace Programm{
  public class Program
  {
    public static void Main(string[] args)
    {
       Farm.Animal cat = new Farm.Animal("Kitty");
       Console.WriteLine(cat);
    }
  }
}
