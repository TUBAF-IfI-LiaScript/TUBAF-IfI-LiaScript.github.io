ace.require(["ace/snippets/pig"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
