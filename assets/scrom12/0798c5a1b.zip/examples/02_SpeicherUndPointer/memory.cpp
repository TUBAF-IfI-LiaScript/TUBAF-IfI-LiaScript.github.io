#include <iostream>

int main(void)
{
    std::cout << "Hello World!" << std::endl;
    return EXIT_SUCCESS;
}
