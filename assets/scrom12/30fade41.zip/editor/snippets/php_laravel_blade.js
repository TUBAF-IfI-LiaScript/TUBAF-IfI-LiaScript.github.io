ace.require(["ace/snippets/php_laravel_blade"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
