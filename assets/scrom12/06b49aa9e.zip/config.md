<!--
author:   Sebastian Zug

email:    sebastian.zug@informatik.tu-freiberg.de

version:  0.0.1
icon: https://upload.wikimedia.org/wikipedia/commons/d/de/Logo_TU_Bergakademie_Freiberg.svg
comment:  This file provides commonly used meta information for all LiaScript courses in the folder

@config.semester: `Sommersemester 2023`
@config.university: `Technische Universität Freiberg`

-->

# Config variables

```
@config.semester:   `Sommersemester 2023`
@config.university: `Technische Universität Freiberg`
```
